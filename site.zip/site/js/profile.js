var fragmentoPerfil = 	'<p> <strong>{{NOME}}</strong></p>' +
						'<p> Funcional: <strong>{{FUNCIONAL}}</strong></p>'+
						'<p>RACF: <strong>{{RACF}}</strong></p>'+
                        '<p>Área: <strong>{{SETOR}}</strong></p>'+
						'<p> Máquina Atual: <strong>{{MAQUINA}}</strong></p>'+
                        '<p>Solicitações: <strong>{{QUANTSOL}}</strong></p>';
					  
					  
					  
//var fragmentoFoto   = '<img src="{{LINKFOTO}}" width="100%">';
var fragmentoFoto   = '<img src="{{LINKFOTO}}" class="img-fluid z-depth-1-half" alt="">';
var fragmentoPedido = '<tr>'+
					  
                      '<td>{{NUMPEDIDO}}</td>'+
                      '<td>{{DATAPEDIDO}}</td>'+
                      '<td>{{OBSERVACOES}}</td>'+
					  '</tr>';


function novoPedido(){
    window.location = "novopedido.html";
}
// este metodo eh um dos mais trabalhosos, pois ele pega a informacao do usuario
// e tem que preencher praticamente a pagina toda.
function carregaUser(){
    var userStr = localStorage.getItem("user");
    if (!userStr){  // se nao tiver isso no localStorage, redireciona para o index (login)
        window.location = "index.html";
    }
    else{
		
        // se o usuario existe armazenado, eu pego, converto-o para JSON
        var user = JSON.parse(userStr);
        // e comeco a preencher as diferentes secoes da minha pagina
        // secao do perfil
        var strPerfil = fragmentoPerfil.replace("{{NOME}}",user.nome)
										.replace("{{FUNCIONAL}}",user.funcional)
										.replace("{{RACF}}",user.racf)
										.replace("{{SETOR}}",user.setor)
										.replace("{{MAQUINA}}",user.maquina)
										.replace("{{EMAIL}}",user.email)
										.replace("{{QUANTSOL}}",user.pedidos.length)
									   ;
        document.getElementById("perfil").innerHTML = strPerfil;

        // secao da foto
        document.getElementById("fotoUser").innerHTML = 
            fragmentoFoto.replace("{{LINKFOTO}}",user.linkFoto);

        // secao dos pedidos
        var strPedidos="";
        for (i=0; i<user.pedidos.length; i++){
            let pedidoatual = fragmentoPedido;
            strPedidos += pedidoatual.replace("{{LINHA}}",i+1) 
									 .replace("{{NUMPEDIDO}}",user.pedidos[i].numPedido) 
									 .replace("{{DATAPEDIDO}}",user.pedidos[i].dataPedido)
                                     .replace("{{OBSERVACOES}}",user.pedidos[i].observacoes);
        }
        document.getElementById("pedidos").innerHTML = strPedidos;
    }
}

function carregaPedidos(){
	 var userStr = localStorage.getItem("user");
    if (!userStr){  // se nao tiver isso no localStorage, redireciona para o index (login)
        window.location = "index.html";
    }
	else{
		
	 var user = JSON.parse(userStr);
	var strPedidos="";
        for (i=0; i<user.pedidos.length; i++){
            let pedidoatual = fragmentoPedido;
            strPedidos += pedidoatual.replace("{{LINHA}}",i+1) 
									 .replace("{{NUMPEDIDO}}",user.pedidos[i].numPedido) 
									 .replace("{{DATAPEDIDO}}",user.pedidos[i].dataPedido)
                                     .replace("{{OBSERVACOES}}",user.pedidos[i].observacoes);
        }
        document.getElementById("pedidos").innerHTML = strPedidos;
	
	}
	
}


function carregaSoftwares(){
    // preciso ver se o usuario ta logado
    var user = localStorage.getItem("user");
    if (!user){
        window.location="index.html";
    }
    else{
        fetch('http://localhost:8080/softwares/disponiveis')
           .then(res=>res.json())
           .then(res=>popula(res));
    }
    // 
}

function carregaHardware(){
    // preciso ver se o usuario ta logado
    var user = localStorage.getItem("user");
    if (!user){
        window.location="index.html";
    }
    else{
        fetch('http://localhost:8080/maquina')
           .then(res=>res.json())
           .then(res=>populaH(res));
    }
    // 
}

function popula(lista){
    var strSoftware = "";
	strSoftware = '<h2 class="my-5 h3 text-center">Escolha os seus softwares</h2>';
	var fragmentoCheck = '<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="{{LINHA}}" name="CheckedS"><label class="custom-control-label" for="{{LINHA}}" value="{{SOFTWARE}}">{{SOFTWARE}}</label></div>';
	
	
	
	
    for (i=0; i<lista.length; i++){
        //strSoftware += "<input type='checkbox' name='itens' value='"+lista[i].id+"'>"+lista[i].descricao +"<br>";
		 let checkatual = fragmentoCheck;
		 strSoftware += checkatual.replace("{{LINHA}}",lista[i].id)
									.replace("{{LINHA}}",lista[i].id)
									.replace("{{SOFTWARE}}",lista[i].descricao)
									.replace("{{SOFTWARE}}",lista[i].descricao);
    }
    document.getElementById("listasw").innerHTML = strSoftware;
	document.getElementById("confirmarbtH").innerHTML = "";
	confirmarbt();
}

function populaH(lista){
    var strHardware = "";
	strHardware = '<h2 class="my-5 h3 text-center">Escolha o seu Hardware</h2>';
	/*var fragmentoCheck = '<div class="custom-control custom-checkbox"><input type="checkbox" class="custom-control-input" id="{{LINHA}}" name="CheckedH"><label class="custom-control-label" for="{{LINHA}}">{{HARDWARE}}</label></div>';*/
	
	var fragmentoCheck = '<div class="form-check"><input type="radio" class="form-check-input" id="{{LINHA}}" name="CheckedH" checked><label class="form-check-label" for="{{LINHA}}">{{HARDWARE}}</label></div>'

	
    for (i=0; i<lista.length; i++){
        //strSoftware += "<input type='checkbox' name='itens' value='"+lista[i].id+"'>"+lista[i].descricao +"<br>";
		 let checkatual = fragmentoCheck;
		 strHardware += checkatual.replace("{{LINHA}}",lista[i].id)
									.replace("{{LINHA}}",lista[i].id)
									.replace("{{HARDWARE}}",lista[i].modelo);
    }
    document.getElementById("listasw").innerHTML = strHardware;
	
	confirmarbtH();
}


function confirmarbt(){
	var strBt = "";
    strBt += '<div class="row"><div class="col-md-3"></div><div class="col-1 mr-3"></div><div class="col-12 mr-3 flex-center"><a target="_blank" class="btn btn-indigo btn-md waves-effect waves-light" onclick="pedidoDB()">Finalizar Pedido<i class="fa fa-check ml-1"></i></a></div><div class="col-md-3"></div></div>';
	
    document.getElementById("confirmarbt").innerHTML = strBt;
}

function confirmarbtH(){
	var strBt = "";
    strBt += '<a target="_blank" class="btn btn-indigo btn-md waves-effect waves-light" onclick="pedidoDB()">Finalizar Pedido<i class="fa fa-check ml-1"></i></a></div><div class="col-md-3">';
	
    document.getElementById("confirmarbt").innerHTML = strBt;
	
	var strBtH = "";
    strBtH += '<a target="_blank" class="btn btn-indigo btn-md waves-effect waves-light" onclick="salvarMq()">Instalar Softwares<i class="fas fa-download ml-1"></i></a></div><div class="col-md-3">';
	
    document.getElementById("confirmarbtH").innerHTML = strBtH;
}
let valuesCheckHSalva;

function salvarMq(){
	
	valuesCheckHSalva = getSelectedCheckboxValues('CheckedH');
	
	carregaSoftwares();
	

}

function confirmar(){
    var listaItens = document.getElementsByTagName("input");
    for (i=0; i<listaItens.length;i++){
        console.log(listaItens[i]);
    }
    console.log("fim");
}

function getSelectedCheckboxValues(name) {
    const checkboxes = document.querySelectorAll(`input[name="${name}"]:checked`);
    let values = [];
    checkboxes.forEach((checkbox) => {
        values.push(checkbox.id);
    });
    return values;
}

function pedidoDB(){

	var myHeaders = new Headers();
	myHeaders.append("Content-Type", "application/json");
	
	
	var today = new Date();
	var date = today.getDate() +'/'+(today.getMonth()+1)+'/'+today.getFullYear();
	
	var solicitanteId = "{{USER}}";
	var user = JSON.parse(localStorage.getItem("user"));
	var strsolicitanteId = solicitanteId.replace("{{USER}}",user.id);
	
	let valuesCheckS = getSelectedCheckboxValues('CheckedS');
	let valuesCheckH = valuesCheckHSalva;
	
	if(valuesCheckH == undefined)valuesCheckH = getSelectedCheckboxValues('CheckedH');
	
	var maqID ="";
	if(valuesCheckH.length > 0){
		
		maqID =+valuesCheckH[0];
		
	}
	else{
		maqID='';
	}
	
	var itm='[';
	if(valuesCheckS.length > 0){
		for (i=0; i<valuesCheckS.length;i++){
			itm += '{"itemSoftware":{id:' +parseInt(valuesCheckS[i])+"}}";
			
			if(valuesCheckS.length-1 >i){
				itm += ',';
				
			}
			else{
				itm += ']';
				
			}
		}
    }
	else{
		itm +=']';
	}
	
	
	if(valuesCheckH.length > 0){
		if(valuesCheckS.length > 0){
			var raw = {
			status:"N",
			dataPedido:date,
			observacoes:"Pedido de Hardware e Software",
			solicitante:{"id":strsolicitanteId},
			computador: {"id": maqID},
			itens:[]
			}
			
	
			var cont=0;
			for (i=0; i<valuesCheckS.length;i++){
				var itemSoftware = { itemSoftware : { id: 	parseInt(valuesCheckS[i]) }}
					raw.itens[cont] = itemSoftware;
					cont++;
			
    }	
			
			var requestOptions = {
			method: 'POST',
			headers: myHeaders,
			body: JSON.stringify(raw),
			redirect: 'follow'
			};
		}
		else{
			var raw = {
			status:"N",
			dataPedido:date,
			observacoes:"Pedido de Hardware",
			solicitante:{"id":strsolicitanteId},
			computador: {"id": maqID},
			itens:[]
			}
			var requestOptions = {
			method: 'POST',
			headers: myHeaders,
			body: JSON.stringify(raw),
			redirect: 'follow'
			};
		}
	}
	else{
		
		var raw = {
		status:"N",
		dataPedido:date,
		observacoes:"Pedido de Software",
		solicitante:{"id":strsolicitanteId},
		itens:[]
		}
		
		var cont=0;
		for (i=0; i<valuesCheckS.length;i++){
			var itemSoftware = { itemSoftware : { id: 	parseInt(valuesCheckS[i]) }}
				raw.itens[cont] = itemSoftware;
				cont++;
        
    }
	
		var requestOptions = {
		method: 'POST',
		headers: myHeaders,
		body: JSON.stringify(raw),
		redirect: 'follow'
		};
		
	}	
	
	fetch("http://localhost:8080/pedido/novo", requestOptions)
	.then(response => response.text())
	.then(result => console.log(result))
	.catch(error => console.log('error', error));
	
}


