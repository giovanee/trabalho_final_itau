// funcao so para apagar a mensagem ao clicar nos campos de login/senha
function apagaMsg(){
    document.getElementById("erroMsg").innerHTML = "";  
}

function icons(){
	var opcaoE = document.getElementById("opcaoE").checked;
	if(opcaoE == true){
			var strUser = '<i class="fas fa-envelope prefix grey-text" ></i><input class="form-control" id="racf" type="text" onclick = "apagaMsg()"><label for="racf">E-mail</label>';
	}
	else{
		var strUser = '<i class="fas fa-user prefix grey-text" ></i><input class="form-control" id="racf" type="text" onclick = "apagaMsg()"><label for="racf">Racf</label>';
	}
	
	
	document.getElementById("iconE").innerHTML = strUser;
}

// vou criar uma funcao para autenticar (chamada pelo botao)
function autentica(){
    
	var userStr = localStorage.getItem("user");
    if (!userStr){  
	// recupero os valores digitados nos campos de INPUT
    var login = document.getElementById("racf").value;
    var senha = document.getElementById("password").value;
	var opcaoE = document.getElementById("opcaoE").checked;

	

    // monto um Objeto JSON com esses dados (para enviar para o BAckend JAVA)
    var msgBodyR = {
         racf: login,
         senha: senha
    }
	
	  var msgBodyE = {
         email: login,
         senha: senha
    }

  
	var usuario;
	
	
	if(opcaoE == true){
		var cabecalho = {
			method: 'POST',
			body: JSON.stringify(msgBodyE),
			headers: {
					'Content-Type': 'application/json'
			}
		}
		
		fetch("http://localhost:8080/login/email",cabecalho)
        .then(res => res.json() )  
        .then(res => {             
            usuario = res;         
            console.log(usuario);
            localStorage.setItem("user",JSON.stringify(usuario));
            window.location = "profile.html"; 
        })
        .catch(err=>{          
            console.log(err);
            document.getElementById("erroMsg").innerHTML="EMAIL OU SENHA INVÁLIDOS";
			document.getElementById("erroMsg").style.visibility="visible"
        });
		
	}
	else{
		var cabecalho = {
        method: 'POST',
        body: JSON.stringify(msgBodyR),
        headers: {
                'Content-Type': 'application/json'
        }
		}
		
		fetch("http://localhost:8080/login/racf",cabecalho)
        .then(res => res.json() )  
        .then(res => {             
            usuario = res;         
            console.log(usuario);
            localStorage.setItem("user",JSON.stringify(usuario));
            window.location = "profile.html"; 
        })
        .catch(err=>{          
            console.log(err);
            document.getElementById("erroMsg").innerHTML="RACF OU SENHA INVÁLIDOS";
			document.getElementById("erroMsg").style.visibility="visible"
        });
	}
	}
    else{
		
		 var user = JSON.parse(userStr);
		 var login = user.racf;
		 var senha = user.senha;
		 var msgBodyR = {
         racf: login
		}

		var usuario;
				
		
		var cabecalho = {
        method: 'POST',
        body: JSON.stringify(msgBodyR),
        headers: {
                'Content-Type': 'application/json'
        }
		}
		
		fetch("http://localhost:8080/racfg",cabecalho)
        .then(res => res.json() )  
        .then(res => {             
            usuario = res;         
            console.log(usuario);
            localStorage.setItem("user",JSON.stringify(usuario));
            window.location = "profile.html"; 
        })
        .catch(err=>{          
            console.log(err);
        });
	}
		
	
}

function deslogar(){
	localStorage.clear();
	window.location = "index.html";
}

function solicitacao(){
	window.location = "solicitacao.html";
}
function pedidos(){
	window.location = "pedidos.html";
}
function suporte(){
	window.location = "suporte.html";
}
function logarIn(){
	
	window.location = "profile.html";
}